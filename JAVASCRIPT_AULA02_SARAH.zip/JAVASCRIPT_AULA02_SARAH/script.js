function mostraData(){
    document.getElementById("data").innerHTML = Date();
}

function mostraMsg(){
    alert("Outro alert?? Já tá ficando chato... 🥱🙄")
}